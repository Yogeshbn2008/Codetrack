// CodeTrack Companion - Popup Logic

const CLOUD_API_URL = "https://codetrack-server.onrender.com"
const LOCAL_API_URL = "http://localhost:5000"

let state = {
  token: null,
  user: null,
  apiBaseUrl: CLOUD_API_URL,
  selectedDifficulty: "Medium",
  selectedStatus: "solved",
  selectedInterval: 7
}

// DOM Elements
const authView = document.getElementById("authView")
const mainView = document.getElementById("mainView")
const logoutBtn = document.getElementById("logoutBtn")
const envBadge = document.getElementById("envBadge")
const serverToggleBtn = document.getElementById("serverToggleBtn")
const userGreeting = document.getElementById("userGreeting")
const quickConnectBtn = document.getElementById("quickConnectBtn")
const loginForm = document.getElementById("loginForm")
const authError = document.getElementById("authError")

const logForm = document.getElementById("logForm")
const logError = document.getElementById("logError")
const detectionNotice = document.getElementById("detectionNotice")
const detectionText = document.getElementById("detectionText")
const probTitle = document.getElementById("probTitle")
const probTopic = document.getElementById("probTopic")
const probPattern = document.getElementById("probPattern")
const probNotes = document.getElementById("probNotes")
const probLink = document.getElementById("probLink")
const submitLogBtn = document.getElementById("submitLogBtn")
const submitBtnText = document.getElementById("submitBtnText")

const successPanel = document.getElementById("successPanel")
const successSubtitle = document.getElementById("successSubtitle")
const logAnotherBtn = document.getElementById("logAnotherBtn")
const autoLogToggle = document.getElementById("autoLogToggle")

// Initialize Extension Popup
document.addEventListener("DOMContentLoaded", async () => {
  setupPillListeners()
  setupEventListeners()
  await loadStoredSession()
})

// Setup Pill Toggles
function setupPillListeners() {
  // Difficulty Pills
  document.querySelectorAll("#diffGroup .pill-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#diffGroup .pill-btn").forEach(b => b.classList.remove("active"))
      btn.classList.add("active")
      state.selectedDifficulty = btn.dataset.diff
    })
  })

  // Status Pills
  document.querySelectorAll("#statusGroup .pill-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#statusGroup .pill-btn").forEach(b => b.classList.remove("active"))
      btn.classList.add("active")
      state.selectedStatus = btn.dataset.status
    })
  })

  // Revision Interval Pills
  document.querySelectorAll("#intervalGroup .pill-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#intervalGroup .pill-btn").forEach(b => b.classList.remove("active"))
      btn.classList.add("active")
      state.selectedInterval = parseInt(btn.dataset.days, 10)
    })
  })
}

// Setup Event Listeners
function setupEventListeners() {
  // Toggle Server (Cloud vs Local)
  serverToggleBtn.addEventListener("click", async () => {
    const isCloud = state.apiBaseUrl === CLOUD_API_URL
    state.apiBaseUrl = isCloud ? LOCAL_API_URL : CLOUD_API_URL
    await chrome.storage.local.set({ apiBaseUrl: state.apiBaseUrl })
    updateEnvBadge()
  })

  // Quick Connect from CodeTrack Web Tab
  quickConnectBtn.addEventListener("click", handleQuickConnect)

  // Manual Login Form
  loginForm.addEventListener("submit", handleManualLogin)

  // Logout
  logoutBtn.addEventListener("click", handleLogout)

  // Log Problem Form Submission
  logForm.addEventListener("submit", handleLogProblem)

  // Log Another Problem
  logAnotherBtn.addEventListener("click", () => {
    successPanel.classList.add("hidden")
    logForm.classList.remove("hidden")
    detectActiveTabProblem()
  })

  // Zero-Click Auto-Log Toggle
  if (autoLogToggle) {
    autoLogToggle.addEventListener("change", async (e) => {
      await chrome.storage.local.set({ autoLogEnabled: e.target.checked })
    })
  }
}

// Load Stored Session from Chrome Storage
async function loadStoredSession() {
  const data = await chrome.storage.local.get(["token", "user", "apiBaseUrl", "autoLogEnabled"])
  if (data.apiBaseUrl) {
    state.apiBaseUrl = data.apiBaseUrl
  }
  updateEnvBadge()

  // Initialize toggle (default true)
  if (autoLogToggle) {
    autoLogToggle.checked = data.autoLogEnabled !== false
  }

  if (data.token) {
    state.token = data.token
    state.user = data.user
    showMainView()
  } else {
    // Try auto-discovering session from open CodeTrack tabs silently
    const autoSynced = await attemptSilentAutoConnect()
    if (!autoSynced) {
      showAuthView()
    }
  }
}

function updateEnvBadge() {
  const isCloud = state.apiBaseUrl === CLOUD_API_URL
  envBadge.textContent = isCloud ? "Cloud" : "Local"
  envBadge.className = `env-badge ${isCloud ? "live" : "local"}`
}

function showAuthView() {
  authView.classList.remove("hidden")
  mainView.classList.add("hidden")
  logoutBtn.classList.add("hidden")
  authError.classList.add("hidden")
}

function showMainView() {
  authView.classList.add("hidden")
  mainView.classList.remove("hidden")
  logoutBtn.classList.remove("hidden")
  successPanel.classList.add("hidden")
  logForm.classList.remove("hidden")

  const name = state.user?.name || state.user?.email || "Coder"
  userGreeting.textContent = `Hi, ${name}`

  // Detect LeetCode problem from active tab
  detectActiveTabProblem()
}

// 1-Click Session Auto-Discovery from CodeTrack Web Tab
async function attemptSilentAutoConnect() {
  try {
    const tabs = await chrome.tabs.query({
      url: [
        "https://codetrack-henna.vercel.app/*",
        "http://localhost:5173/*"
      ]
    })

    if (!tabs || tabs.length === 0) return false

    for (const tab of tabs) {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          try {
            const token = localStorage.getItem("token")
            const userStr = localStorage.getItem("user")
            const user = userStr ? JSON.parse(userStr) : null
            return { token, user }
          } catch {
            return null
          }
        }
      })

      if (results && results[0]?.result?.token) {
        const { token, user } = results[0].result
        state.token = token
        state.user = user
        await chrome.storage.local.set({ token, user })
        showMainView()
        return true
      }
    }
    return false
  } catch (err) {
    console.debug("Silent connect skip:", err)
    return false
  }
}

// Handle Manual "Connect from CodeTrack Tab" Click
async function handleQuickConnect() {
  authError.classList.add("hidden")
  quickConnectBtn.disabled = true
  quickConnectBtn.innerHTML = `<span>Searching active tabs...</span>`

  try {
    const connected = await attemptSilentAutoConnect()
    if (!connected) {
      authError.textContent = "No open CodeTrack tab found. Please open codetrack-henna.vercel.app or log in manually below."
      authError.classList.remove("hidden")
    }
  } catch (err) {
    authError.textContent = "Could not sync session: " + err.message
    authError.classList.remove("hidden")
  } finally {
    quickConnectBtn.disabled = false
    quickConnectBtn.innerHTML = `<span class="btn-icon">🔗</span><span>1-Click Connect from CodeTrack Tab</span>`
  }
}

// Handle Manual Login
async function handleManualLogin(e) {
  e.preventDefault()
  authError.classList.add("hidden")
  const email = document.getElementById("loginEmail").value.trim()
  const password = document.getElementById("loginPassword").value

  const submitBtn = document.getElementById("loginSubmitBtn")
  submitBtn.disabled = true
  submitBtn.innerHTML = `<span>Signing in...</span>`

  try {
    const res = await fetch(`${state.apiBaseUrl}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    })

    const data = await res.json()
    if (!res.ok) {
      throw new Error(data.message || "Invalid credentials")
    }

    state.token = data.token
    state.user = data.user
    await chrome.storage.local.set({ token: data.token, user: data.user })
    showMainView()
  } catch (err) {
    authError.textContent = err.message || "Failed to connect to CodeTrack server."
    authError.classList.remove("hidden")
  } finally {
    submitBtn.disabled = false
    submitBtn.innerHTML = `<span>Log In</span>`
  }
}

// Handle Logout
async function handleLogout() {
  state.token = null
  state.user = null
  await chrome.storage.local.remove(["token", "user"])
  showAuthView()
}

// Detect Problem Data from Active Tab
async function detectActiveTabProblem() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    if (!tab || !tab.url) return

    if (tab.url.includes("leetcode.com/problems/")) {
      detectionNotice.className = "detection-notice ready"
      detectionNotice.querySelector(".notice-icon").textContent = "✓"
      detectionText.textContent = "LeetCode problem detected"

      // Send message to content script
      chrome.tabs.sendMessage(tab.id, { action: "GET_PROBLEM_DATA" }, async (response) => {
        if (chrome.runtime.lastError || !response) {
          // Content script might need dynamic injection
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ["content.js"]
            })
            // Retry message
            chrome.tabs.sendMessage(tab.id, { action: "GET_PROBLEM_DATA" }, (retryResponse) => {
              if (retryResponse) populateProblemForm(retryResponse)
            })
          } catch (e) {
            console.warn("Could not inject content script:", e)
          }
        } else {
          populateProblemForm(response)
        }
      })
    } else {
      detectionNotice.className = "detection-notice warning"
      detectionNotice.querySelector(".notice-icon").textContent = "ℹ"
      detectionText.textContent = "Not on LeetCode. Enter details manually or open a problem."
      probLink.value = tab.url
    }
  } catch (err) {
    console.error("Tab detection error:", err)
  }
}

// Populate Form with Extracted Data
function populateProblemForm(data) {
  if (data.title) probTitle.value = data.title
  if (data.topic) probTopic.value = data.topic
  if (data.link) probLink.value = data.link

  // Set Difficulty Pill
  if (data.difficulty) {
    state.selectedDifficulty = data.difficulty
    document.querySelectorAll("#diffGroup .pill-btn").forEach(btn => {
      btn.classList.toggle("active", btn.dataset.diff.toLowerCase() === data.difficulty.toLowerCase())
    })
  }

  // Set Status Pill
  if (data.status) {
    state.selectedStatus = data.status
    document.querySelectorAll("#statusGroup .pill-btn").forEach(btn => {
      btn.classList.toggle("active", btn.dataset.status === data.status)
    })
  }
}

// Submit Problem to CodeTrack API
async function handleLogProblem(e) {
  e.preventDefault()
  logError.classList.add("hidden")

  const title = probTitle.value.trim()
  if (!title) {
    logError.textContent = "Problem title is required."
    logError.classList.remove("hidden")
    return
  }

  submitLogBtn.disabled = true
  submitBtnText.textContent = "Saving to CodeTrack..."

  const payload = {
    title,
    platform: "LeetCode",
    difficulty: state.selectedDifficulty,
    topic: probTopic.value.trim() || "Algorithms",
    pattern: probPattern.value.trim() || undefined,
    status: state.selectedStatus,
    revisionIntervalDays: state.selectedInterval,
    notes: probNotes.value.trim() || undefined,
    link: probLink.value.trim() || undefined
  }

  try {
    const res = await fetch(`${state.apiBaseUrl}/api/problems`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${state.token}`
      },
      body: JSON.stringify(payload)
    })

    const data = await res.json()
    if (!res.ok) {
      if (res.status === 401) {
        // Token expired
        await handleLogout()
        throw new Error("Session expired. Please sign in again.")
      }
      throw new Error(data.message || "Failed to log problem.")
    }

    // Show Success Panel
    logForm.classList.add("hidden")
    successSubtitle.textContent = `"${data.title}" successfully logged with ${data.difficulty} difficulty.`
    successPanel.classList.remove("hidden")

  } catch (err) {
    logError.textContent = err.message || "Network error. Please try again."
    logError.classList.remove("hidden")
  } finally {
    submitLogBtn.disabled = false
    submitBtnText.textContent = "Log to CodeTrack"
  }
}
