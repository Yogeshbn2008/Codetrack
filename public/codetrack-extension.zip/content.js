// CodeTrack Companion - Content Script for LeetCode DOM Extraction & Zero-Click Auto-Logger

let lastLoggedPath = ""
let lastLoggedTime = 0
let isSubmittingAutoLog = false

function extractLeetCodeData() {
  try {
    let title = ""
    let difficulty = "Medium"
    let topic = "Algorithms"
    let status = "attempted"
    const link = window.location.origin + window.location.pathname.replace(/\/submissions.*$/, '')

    // 1. Extract Title
    // Try modern LeetCode title header selector
    const titleEl = document.querySelector('div[class*="text-title-large"]') ||
                    document.querySelector('[data-cy="question-title"]') ||
                    document.querySelector('div.flex-1 > div > a[href*="/problems/"]')

    if (titleEl && titleEl.textContent.trim()) {
      // Remove leading question number e.g. "1. Two Sum" -> "Two Sum"
      title = titleEl.textContent.trim().replace(/^\d+\.\s*/, '')
    } else {
      // Fallback from document.title: "1. Two Sum - LeetCode"
      const docTitle = document.title || ""
      const match = docTitle.match(/^(\d+\.\s*)?([^-–|]+)/)
      if (match && match[2]) {
        title = match[2].trim()
      }
    }

    // 2. Extract Difficulty
    const diffEl = document.querySelector('div[class*="text-difficulty-"]') ||
                   document.querySelector('div[class*="text-olive"]') ||
                   document.querySelector('div[class*="text-yellow"]') ||
                   document.querySelector('div[class*="text-pink"]')

    if (diffEl && diffEl.textContent.trim()) {
      const text = diffEl.textContent.trim().toLowerCase()
      if (text.includes('easy')) difficulty = 'Easy'
      else if (text.includes('hard')) difficulty = 'Hard'
      else if (text.includes('medium')) difficulty = 'Medium'
    } else {
      const bodyText = document.body.innerText || ""
      if (/\bEasy\b/.test(bodyText) && !/\bMedium\b/.test(bodyText)) difficulty = 'Easy'
      else if (/\bHard\b/.test(bodyText)) difficulty = 'Hard'
    }

    // 3. Extract Topic Tags
    const tagElements = document.querySelectorAll('a[href*="/tag/"]')
    if (tagElements && tagElements.length > 0) {
      const tags = Array.from(tagElements)
        .map(el => el.textContent.trim())
        .filter(t => t && t.length > 1)
      if (tags.length > 0) {
        topic = tags[0]
      }
    }

    // 4. Check if Solved / Accepted
    const acceptedEl = document.querySelector('[data-e2e-tracking-id="console_result_state"]') ||
                       document.querySelector('span[class*="text-green"]') ||
                       document.querySelector('div[class*="text-green"]')

    if (acceptedEl && acceptedEl.textContent.toLowerCase().includes('accepted')) {
      status = 'solved'
    } else if (document.body.innerText.includes('Accepted') && document.body.innerText.includes('Runtime')) {
      status = 'solved'
    }

    return {
      title: title || "LeetCode Problem",
      difficulty,
      topic,
      platform: "LeetCode",
      link,
      status
    }
  } catch (err) {
    console.error("CodeTrack Companion extraction error:", err)
    return {
      title: document.title ? document.title.replace(/\s*-\s*LeetCode.*$/i, '').trim() : "LeetCode Problem",
      difficulty: "Medium",
      topic: "Algorithms",
      platform: "LeetCode",
      link: window.location.href,
      status: "attempted"
    }
  }
}

// In-Page Floating Toast Notification Banner
function showCodeTrackToast(title, difficulty, nextDays = 7) {
  const existing = document.getElementById('codetrack-toast-container')
  if (existing) existing.remove()

  const toast = document.createElement('div')
  toast.id = 'codetrack-toast-container'
  toast.innerHTML = `
    <div class="ct-toast-card">
      <div class="ct-toast-icon">⚡</div>
      <div class="ct-toast-content">
        <div class="ct-toast-header">
          <span class="ct-toast-badge">CodeTrack Auto-Logged</span>
          <span class="ct-toast-diff ct-diff-${String(difficulty).toLowerCase()}">${difficulty}</span>
        </div>
        <div class="ct-toast-title">"${title}" Logged!</div>
        <div class="ct-toast-sub">SuperMemo-2 spaced review scheduled in ${nextDays} days.</div>
        <div class="ct-toast-actions">
          <a href="https://codetrack-henna.vercel.app/dashboard" target="_blank" class="ct-toast-link">
            Open Dashboard ↗
          </a>
        </div>
      </div>
      <button class="ct-toast-close" id="ctToastClose">✕</button>
    </div>
  `

  injectToastStyles()
  document.body.appendChild(toast)

  document.getElementById('ctToastClose')?.addEventListener('click', () => {
    toast.classList.add('ct-toast-hiding')
    setTimeout(() => toast.remove(), 300)
  })

  setTimeout(() => {
    if (document.body.contains(toast)) {
      toast.classList.add('ct-toast-hiding')
      setTimeout(() => toast.remove(), 300)
    }
  }, 6500)
}

function injectToastStyles() {
  if (document.getElementById('codetrack-toast-styles')) return

  const style = document.createElement('style')
  style.id = 'codetrack-toast-styles'
  style.textContent = `
    #codetrack-toast-container {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      animation: ctSlideIn 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes ctSlideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    .ct-toast-hiding {
      animation: ctSlideOut 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
    }
    @keyframes ctSlideOut {
      from { transform: translateX(0); opacity: 1; }
      to { transform: translateX(100%); opacity: 0; }
    }
    .ct-toast-card {
      background: #0f172a;
      border: 1px solid rgba(99, 102, 241, 0.5);
      border-radius: 12px;
      padding: 14px 16px;
      display: flex;
      gap: 12px;
      align-items: flex-start;
      color: #f8fafc;
      width: 320px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6), 0 0 20px rgba(99, 102, 241, 0.25);
    }
    .ct-toast-icon {
      width: 28px;
      height: 28px;
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      flex-shrink: 0;
    }
    .ct-toast-content {
      flex: 1;
    }
    .ct-toast-header {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 4px;
    }
    .ct-toast-badge {
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #818cf8;
    }
    .ct-toast-diff {
      font-size: 9.5px;
      font-weight: 700;
      padding: 1px 5px;
      border-radius: 4px;
      text-transform: uppercase;
    }
    .ct-diff-easy { background: rgba(16, 185, 129, 0.2); color: #34d399; }
    .ct-diff-medium { background: rgba(245, 158, 11, 0.2); color: #fbbf24; }
    .ct-diff-hard { background: rgba(239, 68, 68, 0.2); color: #f87171; }
    .ct-toast-title {
      font-size: 13.5px;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 2px;
    }
    .ct-toast-sub {
      font-size: 11.5px;
      color: #94a3b8;
      margin-bottom: 8px;
      line-height: 1.3;
    }
    .ct-toast-actions {
      display: flex;
      gap: 8px;
    }
    .ct-toast-link {
      font-size: 11px;
      font-weight: 600;
      color: #818cf8;
      text-decoration: none;
      transition: color 0.2s;
    }
    .ct-toast-link:hover {
      color: #c7d2fe;
    }
    .ct-toast-close {
      background: transparent;
      border: none;
      color: #64748b;
      cursor: pointer;
      font-size: 13px;
      padding: 2px;
      line-height: 1;
      transition: color 0.2s;
    }
    .ct-toast-close:hover {
      color: #ffffff;
    }
  `
  document.head.appendChild(style)
}

// Zero-Click Auto-Log Submission Engine
async function attemptAutoLogSubmission() {
  if (isSubmittingAutoLog) return
  if (!window.location.pathname.includes('/problems/')) return

  // Deduplication check: ignore if logged in the last 45s for the same problem
  const currentPath = window.location.pathname.replace(/\/submissions.*$/, '')
  if (currentPath === lastLoggedPath && (Date.now() - lastLoggedTime < 45000)) {
    return
  }

  // Check for Accepted state in DOM
  const isAccepted = checkIsAcceptedDOM()
  if (!isAccepted) return

  // Verify extension storage for token & autoLogEnabled
  chrome.storage.local.get(['token', 'apiBaseUrl', 'autoLogEnabled', 'defaultInterval'], async (storage) => {
    if (!storage.token) return
    if (storage.autoLogEnabled === false) return

    const apiBaseUrl = storage.apiBaseUrl || "https://codetrack-server.onrender.com"
    const nextDays = storage.defaultInterval || 7

    isSubmittingAutoLog = true
    lastLoggedPath = currentPath
    lastLoggedTime = Date.now()

    const probData = extractLeetCodeData()

    const payload = {
      title: probData.title,
      platform: "LeetCode",
      difficulty: probData.difficulty,
      topic: probData.topic || "Algorithms",
      status: "solved",
      revisionIntervalDays: nextDays,
      link: probData.link
    }

    try {
      const res = await fetch(`${apiBaseUrl}/api/problems`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${storage.token}`
        },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        showCodeTrackToast(probData.title, probData.difficulty, nextDays)
      }
    } catch (err) {
      console.warn("CodeTrack auto-log submission error:", err)
    } finally {
      isSubmittingAutoLog = false
    }
  })
}

// Detect Accepted verdict across different LeetCode UI variations
function checkIsAcceptedDOM() {
  // Check console result element
  const stateEl = document.querySelector('[data-e2e-tracking-id="console_result_state"]')
  if (stateEl && stateEl.textContent.trim().toLowerCase() === 'accepted') {
    return true
  }

  // Check submission result container
  const subResultEl = document.querySelector('[data-e2e-tracking-id="submission-result"]') ||
                      document.querySelector('div[class*="text-green-s"]') ||
                      document.querySelector('div[class*="text-green-500"]')
  if (subResultEl && subResultEl.textContent.toLowerCase().includes('accepted')) {
    return true
  }

  // Check for green status element on result screen
  const greenSpans = document.querySelectorAll('span[class*="text-green"], div[class*="text-green"]')
  for (const span of greenSpans) {
    if (span.textContent.trim().toLowerCase() === 'accepted') {
      return true
    }
  }

  return false
}

// Real-Time DOM Observer for Zero-Click Detection
let observerDebounce = null
const observer = new MutationObserver(() => {
  if (observerDebounce) clearTimeout(observerDebounce)
  observerDebounce = setTimeout(() => {
    attemptAutoLogSubmission()
  }, 600)
})

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
})

// Listen for manual requests from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'GET_PROBLEM_DATA') {
    const data = extractLeetCodeData()
    sendResponse(data)
  }
  return true
})
