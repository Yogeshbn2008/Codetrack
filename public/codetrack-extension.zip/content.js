// CodeTrack Companion - Content Script for LeetCode DOM Extraction

function extractLeetCodeData() {
  try {
    let title = ""
    let difficulty = "Medium"
    let topic = "Algorithms"
    let status = "attempted"
    const link = window.location.origin + window.location.pathname.replace(/\/submissions.*$/, '')

    // 1. Extract Title
    // Try modern LeetCode title header selector
    const titleEl = document.querySelector('div[class*="text-title-large"]') ||
                    document.querySelector('[data-cy="question-title"]') ||
                    document.querySelector('div.flex-1 > div > a[href*="/problems/"]')

    if (titleEl && titleEl.textContent.trim()) {
      // Remove leading question number e.g. "1. Two Sum" -> "Two Sum"
      title = titleEl.textContent.trim().replace(/^\d+\.\s*/, '')
    } else {
      // Fallback from document.title: "1. Two Sum - LeetCode"
      const docTitle = document.title || ""
      const match = docTitle.match(/^(\d+\.\s*)?([^-–|]+)/)
      if (match && match[2]) {
        title = match[2].trim()
      }
    }

    // 2. Extract Difficulty
    const diffEl = document.querySelector('div[class*="text-difficulty-"]') ||
                   document.querySelector('div[class*="text-olive"]') ||
                   document.querySelector('div[class*="text-yellow"]') ||
                   document.querySelector('div[class*="text-pink"]')

    if (diffEl && diffEl.textContent.trim()) {
      const text = diffEl.textContent.trim().toLowerCase()
      if (text.includes('easy')) difficulty = 'Easy'
      else if (text.includes('hard')) difficulty = 'Hard'
      else if (text.includes('medium')) difficulty = 'Medium'
    } else {
      // Search body for difficulty text
      const bodyText = document.body.innerText || ""
      if (/\bEasy\b/.test(bodyText) && !/\bMedium\b/.test(bodyText)) difficulty = 'Easy'
      else if (/\bHard\b/.test(bodyText)) difficulty = 'Hard'
    }

    // 3. Extract Topic Tags
    const tagElements = document.querySelectorAll('a[href*="/tag/"]')
    if (tagElements && tagElements.length > 0) {
      const tags = Array.from(tagElements)
        .map(el => el.textContent.trim())
        .filter(t => t && t.length > 1)
      if (tags.length > 0) {
        topic = tags[0] // Primary topic
      }
    }

    // 4. Check if Solved / Accepted
    const acceptedEl = document.querySelector('[data-e2e-tracking-id="console_result_state"]') ||
                       document.querySelector('span[class*="text-green"]') ||
                       document.querySelector('div[class*="text-green"]')

    if (acceptedEl && acceptedEl.textContent.toLowerCase().includes('accepted')) {
      status = 'solved'
    } else if (document.body.innerText.includes('Accepted') && document.body.innerText.includes('Runtime')) {
      status = 'solved'
    }

    return {
      title: title || "LeetCode Problem",
      difficulty,
      topic,
      platform: "LeetCode",
      link,
      status
    }
  } catch (err) {
    console.error("CodeTrack Companion extraction error:", err)
    return {
      title: document.title ? document.title.replace(/\s*-\s*LeetCode.*$/i, '').trim() : "LeetCode Problem",
      difficulty: "Medium",
      topic: "Algorithms",
      platform: "LeetCode",
      link: window.location.href,
      status: "attempted"
    }
  }
}

// Listen for requests from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'GET_PROBLEM_DATA') {
    const data = extractLeetCodeData()
    sendResponse(data)
  }
  return true
})
