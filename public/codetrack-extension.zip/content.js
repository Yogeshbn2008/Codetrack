// CodeTrack Companion - Multi-Platform Content Script (LeetCode, GFG, Codeforces, NeetCode)

let lastLoggedPath = ""
let lastLoggedTime = 0
let isSubmittingAutoLog = false

// Detect current active platform
function detectPlatform() {
  const host = window.location.hostname.toLowerCase()
  if (host.includes('leetcode.com')) return 'LeetCode'
  if (host.includes('geeksforgeeks.org')) return 'GeeksforGeeks'
  if (host.includes('codeforces.com')) return 'Codeforces'
  if (host.includes('neetcode.io')) return 'NeetCode'
  return 'Competitive Programming'
}

// Universal Problem Extractor
function extractProblemData() {
  const platform = detectPlatform()

  switch (platform) {
    case 'LeetCode':
      return extractLeetCode()
    case 'GeeksforGeeks':
      return extractGeeksforGeeks()
    case 'Codeforces':
      return extractCodeforces()
    case 'NeetCode':
      return extractNeetCode()
    default:
      return extractGeneric(platform)
  }
}

// 1. LeetCode Extractor
function extractLeetCode() {
  try {
    let title = ""
    let difficulty = "Medium"
    let topic = "Algorithms"
    let status = "attempted"
    const link = window.location.origin + window.location.pathname.replace(/\/submissions.*$/, '')

    // Title
    const titleEl = document.querySelector('div[class*="text-title-large"]') ||
                    document.querySelector('[data-cy="question-title"]') ||
                    document.querySelector('div.flex-1 > div > a[href*="/problems/"]')

    if (titleEl && titleEl.textContent.trim()) {
      title = titleEl.textContent.trim().replace(/^\d+\.\s*/, '')
    } else {
      const docTitle = document.title || ""
      const match = docTitle.match(/^(\d+\.\s*)?([^-–|]+)/)
      if (match && match[2]) title = match[2].trim()
    }

    // Difficulty
    const diffEl = document.querySelector('div[class*="text-difficulty-"]') ||
                   document.querySelector('div[class*="text-olive"]') ||
                   document.querySelector('div[class*="text-yellow"]') ||
                   document.querySelector('div[class*="text-pink"]')

    if (diffEl && diffEl.textContent.trim()) {
      const text = diffEl.textContent.trim().toLowerCase()
      if (text.includes('easy')) difficulty = 'Easy'
      else if (text.includes('hard')) difficulty = 'Hard'
      else if (text.includes('medium')) difficulty = 'Medium'
    }

    // Topic Tags
    const tagElements = document.querySelectorAll('a[href*="/tag/"]')
    if (tagElements && tagElements.length > 0) {
      const tags = Array.from(tagElements)
        .map(el => el.textContent.trim())
        .filter(t => t && t.length > 1)
      if (tags.length > 0) topic = tags[0]
    }

    // Status
    if (checkIsAcceptedDOM()) status = 'solved'

    return {
      title: title || "LeetCode Problem",
      difficulty,
      topic,
      platform: "LeetCode",
      link,
      status
    }
  } catch (err) {
    console.error("LeetCode extraction error:", err)
    return extractGeneric("LeetCode")
  }
}

// 2. GeeksforGeeks Extractor
function extractGeeksforGeeks() {
  try {
    let title = ""
    let difficulty = "Medium"
    let topic = "Data Structures"
    let status = "attempted"
    const link = window.location.origin + window.location.pathname

    // Title
    const titleEl = document.querySelector('h1[class*="problem-title"]') ||
                    document.querySelector('div[class*="problem-title"]') ||
                    document.querySelector('h3[class*="problemTabTitle"]') ||
                    document.querySelector('.problem-title')

    if (titleEl && titleEl.textContent.trim()) {
      title = titleEl.textContent.trim().replace(/^\d+\.\s*/, '')
    } else {
      title = document.title
        .replace(/\s*-\s*GeeksforGeeks\s*$/i, '')
        .replace(/\s*\|\s*Practice\s*\|\s*GeeksforGeeks\s*$/i, '')
        .replace(/\s*\|\s*Practice.*$/i, '')
        .trim()
    }

    // Difficulty (School, Basic, Easy, Medium, Hard)
    const diffEl = document.querySelector('[class*="problemLevel"]') ||
                   document.querySelector('[class*="difficulty"]') ||
                   document.querySelector('div[class*="problems_header_content"] span')

    const bodyText = (diffEl?.textContent || document.body.innerText || "").toLowerCase()
    if (bodyText.includes('hard')) difficulty = 'Hard'
    else if (bodyText.includes('medium')) difficulty = 'Medium'
    else if (bodyText.includes('easy') || bodyText.includes('basic') || bodyText.includes('school')) difficulty = 'Easy'

    // Topic Tags
    const tagEls = document.querySelectorAll('a[href*="/explore?category"], a[href*="/topics/"], span[class*="topic-tag"]')
    if (tagEls && tagEls.length > 0) {
      const tags = Array.from(tagEls).map(el => el.textContent.trim()).filter(t => t.length > 1)
      if (tags.length > 0) topic = tags[0]
    }

    if (checkIsAcceptedDOM()) status = 'solved'

    return {
      title: title || "GeeksforGeeks Problem",
      difficulty,
      topic,
      platform: "GeeksforGeeks",
      link,
      status
    }
  } catch (err) {
    console.error("GeeksforGeeks extraction error:", err)
    return extractGeneric("GeeksforGeeks")
  }
}

// 3. Codeforces Extractor
function extractCodeforces() {
  try {
    let title = ""
    let difficulty = "Medium"
    let topic = "Algorithms"
    let status = "attempted"
    const link = window.location.href.split('?')[0]

    // Title: e.g. "A. Watermelon"
    const titleEl = document.querySelector('.problem-statement .header .title')
    if (titleEl && titleEl.textContent.trim()) {
      // Remove problem index prefix e.g. "A. " or "123A. "
      title = titleEl.textContent.trim().replace(/^[A-Z0-9]+\.\s*/i, '')
    } else {
      title = document.title.replace(/Problem - \d+[A-Z0-9]* - Codeforces/i, '').replace(/ - Codeforces/i, '').trim()
    }

    // Difficulty: Check rating tag e.g. "*800" or "*1500"
    const diffTagEl = document.querySelector('span.tag-box[title="Difficulty"]')
    if (diffTagEl && diffTagEl.textContent) {
      const rating = parseInt(diffTagEl.textContent.replace('*', '').trim(), 10)
      if (!isNaN(rating)) {
        if (rating <= 1200) difficulty = 'Easy'
        else if (rating <= 1800) difficulty = 'Medium'
        else difficulty = 'Hard'
      }
    } else {
      // Guess from problem index letter (A/B = Easy, C/D = Medium, E+ = Hard)
      const pathname = window.location.pathname.toUpperCase()
      if (pathname.includes('/PROBLEM/A') || pathname.includes('/PROBLEM/B')) difficulty = 'Easy'
      else if (pathname.includes('/PROBLEM/C') || pathname.includes('/PROBLEM/D')) difficulty = 'Medium'
      else if (pathname.includes('/PROBLEM/E') || pathname.includes('/PROBLEM/F')) difficulty = 'Hard'
    }

    // Topic Tags
    const tags = Array.from(document.querySelectorAll('span.tag-box'))
      .map(el => el.textContent.trim())
      .filter(t => !t.startsWith('*') && t.length > 1)

    if (tags.length > 0) {
      // Capitalize tag
      topic = tags[0].charAt(0).toUpperCase() + tags[0].slice(1)
    }

    if (checkIsAcceptedDOM()) status = 'solved'

    return {
      title: title || "Codeforces Problem",
      difficulty,
      topic,
      platform: "Codeforces",
      link,
      status
    }
  } catch (err) {
    console.error("Codeforces extraction error:", err)
    return extractGeneric("Codeforces")
  }
}

// 4. NeetCode Extractor
function extractNeetCode() {
  try {
    let title = ""
    let difficulty = "Medium"
    let topic = "Algorithms"
    let status = "attempted"
    const link = window.location.href

    const titleEl = document.querySelector('h1') || document.querySelector('h2')
    if (titleEl && titleEl.textContent.trim()) {
      title = titleEl.textContent.trim()
    } else {
      title = document.title.replace(/\s*-\s*NeetCode.*$/i, '').trim()
    }

    const text = document.body.innerText.toLowerCase()
    if (text.includes('hard') && !text.includes('medium')) difficulty = 'Hard'
    else if (text.includes('easy')) difficulty = 'Easy'
    else difficulty = 'Medium'

    if (checkIsAcceptedDOM()) status = 'solved'

    return {
      title: title || "NeetCode Problem",
      difficulty,
      topic,
      platform: "NeetCode",
      link,
      status
    }
  } catch (err) {
    return extractGeneric("NeetCode")
  }
}

// Generic Fallback Extractor
function extractGeneric(platform) {
  return {
    title: document.title ? document.title.split(/[-–|]/)[0].trim() : `${platform} Problem`,
    difficulty: "Medium",
    topic: "Algorithms",
    platform,
    link: window.location.href,
    status: "attempted"
  }
}

// Detect Accepted verdict across all supported platforms
function checkIsAcceptedDOM() {
  const platform = detectPlatform()
  const bodyText = document.body.innerText

  if (platform === 'LeetCode') {
    const stateEl = document.querySelector('[data-e2e-tracking-id="console_result_state"]')
    if (stateEl && stateEl.textContent.trim().toLowerCase() === 'accepted') return true

    const subResultEl = document.querySelector('[data-e2e-tracking-id="submission-result"]') ||
                        document.querySelector('div[class*="text-green-s"]') ||
                        document.querySelector('div[class*="text-green-500"]')
    if (subResultEl && subResultEl.textContent.toLowerCase().includes('accepted')) return true

    const greenSpans = document.querySelectorAll('span[class*="text-green"], div[class*="text-green"]')
    for (const span of greenSpans) {
      if (span.textContent.trim().toLowerCase() === 'accepted') return true
    }
    if (bodyText.includes('Accepted') && bodyText.includes('Runtime')) return true
  }

  if (platform === 'GeeksforGeeks') {
    if (bodyText.includes('Problem Solved Successfully') ||
        bodyText.includes('Correct Answer') ||
        bodyText.includes('Test Cases Passed:')) {
      return true
    }
    const gfgSuccess = document.querySelector('[class*="submission-status"], [class*="status-text"]')
    if (gfgSuccess && gfgSuccess.textContent.toLowerCase().includes('correct')) return true
  }

  if (platform === 'Codeforces') {
    const acceptedSpan = document.querySelector('span.verdict-accepted')
    if (acceptedSpan) return true
    if (bodyText.includes('Accepted') && (bodyText.includes('Memory:') || bodyText.includes('Verdict: Accepted'))) return true
  }

  if (platform === 'NeetCode') {
    if (bodyText.includes('Accepted') || document.querySelector('.text-green-500')) return true
  }

  return false
}

// In-Page Floating Toast Notification Banner
function showCodeTrackToast(title, platform, difficulty, nextDays = 7) {
  const existing = document.getElementById('codetrack-toast-container')
  if (existing) existing.remove()

  const toast = document.createElement('div')
  toast.id = 'codetrack-toast-container'
  toast.innerHTML = `
    <div class="ct-toast-card">
      <div class="ct-toast-icon">⚡</div>
      <div class="ct-toast-content">
        <div class="ct-toast-header">
          <span class="ct-toast-badge">${platform} Auto-Logged</span>
          <span class="ct-toast-diff ct-diff-${String(difficulty).toLowerCase()}">${difficulty}</span>
        </div>
        <div class="ct-toast-title">"${title}" Logged!</div>
        <div class="ct-toast-sub">SuperMemo-2 spaced review scheduled in ${nextDays} days.</div>
        <div class="ct-toast-actions">
          <a href="https://codetrack-henna.vercel.app/dashboard" target="_blank" class="ct-toast-link">
            Open Dashboard ↗
          </a>
        </div>
      </div>
      <button class="ct-toast-close" id="ctToastClose">✕</button>
    </div>
  `

  injectToastStyles()
  document.body.appendChild(toast)

  document.getElementById('ctToastClose')?.addEventListener('click', () => {
    toast.classList.add('ct-toast-hiding')
    setTimeout(() => toast.remove(), 300)
  })

  setTimeout(() => {
    if (document.body.contains(toast)) {
      toast.classList.add('ct-toast-hiding')
      setTimeout(() => toast.remove(), 300)
    }
  }, 6500)
}

function injectToastStyles() {
  if (document.getElementById('codetrack-toast-styles')) return

  const style = document.createElement('style')
  style.id = 'codetrack-toast-styles'
  style.textContent = `
    #codetrack-toast-container {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      animation: ctSlideIn 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes ctSlideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    .ct-toast-hiding {
      animation: ctSlideOut 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
    }
    @keyframes ctSlideOut {
      from { transform: translateX(0); opacity: 1; }
      to { transform: translateX(100%); opacity: 0; }
    }
    .ct-toast-card {
      background: #0f172a;
      border: 1px solid rgba(99, 102, 241, 0.5);
      border-radius: 12px;
      padding: 14px 16px;
      display: flex;
      gap: 12px;
      align-items: flex-start;
      color: #f8fafc;
      width: 320px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6), 0 0 20px rgba(99, 102, 241, 0.25);
    }
    .ct-toast-icon {
      width: 28px;
      height: 28px;
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      flex-shrink: 0;
    }
    .ct-toast-content {
      flex: 1;
    }
    .ct-toast-header {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 4px;
    }
    .ct-toast-badge {
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #818cf8;
    }
    .ct-toast-diff {
      font-size: 9.5px;
      font-weight: 700;
      padding: 1px 5px;
      border-radius: 4px;
      text-transform: uppercase;
    }
    .ct-diff-easy { background: rgba(16, 185, 129, 0.2); color: #34d399; }
    .ct-diff-medium { background: rgba(245, 158, 11, 0.2); color: #fbbf24; }
    .ct-diff-hard { background: rgba(239, 68, 68, 0.2); color: #f87171; }
    .ct-toast-title {
      font-size: 13.5px;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 2px;
    }
    .ct-toast-sub {
      font-size: 11.5px;
      color: #94a3b8;
      margin-bottom: 8px;
      line-height: 1.3;
    }
    .ct-toast-actions {
      display: flex;
      gap: 8px;
    }
    .ct-toast-link {
      font-size: 11px;
      font-weight: 600;
      color: #818cf8;
      text-decoration: none;
      transition: color 0.2s;
    }
    .ct-toast-link:hover {
      color: #c7d2fe;
    }
    .ct-toast-close {
      background: transparent;
      border: none;
      color: #64748b;
      cursor: pointer;
      font-size: 13px;
      padding: 2px;
      line-height: 1;
      transition: color 0.2s;
    }
    .ct-toast-close:hover {
      color: #ffffff;
    }
  `
  document.head.appendChild(style)
}

// Zero-Click Auto-Log Submission Engine
async function attemptAutoLogSubmission() {
  if (isSubmittingAutoLog) return

  // Deduplication check: ignore if logged in the last 45s for the same problem
  const currentPath = window.location.pathname.replace(/\/submissions.*$/, '')
  if (currentPath === lastLoggedPath && (Date.now() - lastLoggedTime < 45000)) {
    return
  }

  // Check for Accepted state in DOM
  const isAccepted = checkIsAcceptedDOM()
  if (!isAccepted) return

  // Verify extension storage for token & autoLogEnabled
  chrome.storage.local.get(['token', 'apiBaseUrl', 'autoLogEnabled', 'defaultInterval'], async (storage) => {
    if (!storage.token) return
    if (storage.autoLogEnabled === false) return

    const apiBaseUrl = storage.apiBaseUrl || "https://codetrack-server.onrender.com"
    const nextDays = storage.defaultInterval || 7

    isSubmittingAutoLog = true
    lastLoggedPath = currentPath
    lastLoggedTime = Date.now()

    const probData = extractProblemData()

    const payload = {
      title: probData.title,
      platform: probData.platform,
      difficulty: probData.difficulty,
      topic: probData.topic || "Algorithms",
      status: "solved",
      revisionIntervalDays: nextDays,
      link: probData.link
    }

    try {
      const res = await fetch(`${apiBaseUrl}/api/problems`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${storage.token}`
        },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        showCodeTrackToast(probData.title, probData.platform, probData.difficulty, nextDays)
      }
    } catch (err) {
      console.warn("CodeTrack auto-log submission error:", err)
    } finally {
      isSubmittingAutoLog = false
    }
  })
}

// Real-Time DOM Observer for Zero-Click Detection
let observerDebounce = null
const observer = new MutationObserver(() => {
  if (observerDebounce) clearTimeout(observerDebounce)
  observerDebounce = setTimeout(() => {
    attemptAutoLogSubmission()
  }, 600)
})

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
})

// Listen for manual requests from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'GET_PROBLEM_DATA') {
    const data = extractProblemData()
    sendResponse(data)
  }
  return true
})
