# ⚡ CodeTrack Companion — Manifest V3 Chrome Extension (v1.1.0)

Universal 1-Click & Zero-Click auto-logger for **LeetCode, GeeksforGeeks, Codeforces & NeetCode** directly into your CodeTrack account.

> 📦 **Pre-packaged Release:** `CodeTrack-Companion-v1.1.0.zip` (included in repository)  
> 🌐 **Direct Web Download:** [https://codetrack-henna.vercel.app/codetrack-extension.zip](https://codetrack-henna.vercel.app/codetrack-extension.zip)

---

## 🚀 How to Install in Google Chrome

1. Open Google Chrome and navigate to:
   ```
   chrome://extensions
   ```
2. In the top-right corner, toggle on **"Developer mode"**.
3. Click the **"Load unpacked"** button in the top left.
4. Select the directory:
   ```
   C:\Users\bnyog\OneDrive\Desktop\codetrack-extension
   ```
5. Pin **CodeTrack Companion** to your Chrome toolbar for instant access!

---

## ⚡ Features & Workflow

- **Multi-Platform Support**:
  - 🟡 **LeetCode**: `leetcode.com/problems/*` (Title, Difficulty, Topics, Acceptance)
  - 🟢 **GeeksforGeeks**: `geeksforgeeks.org/problems/*` (Normalized Difficulty, Categories, Solved Status)
  - 🔵 **Codeforces**: `codeforces.com/problemset/problem/*` & contest problems (Title without letter prefix, Rating-based difficulty `*800-*2000`, Problem tags)
  - 🟣 **NeetCode**: `neetcode.io/problems/*` (Roadmap categories, Difficulty)
- **⚡ Zero-Click Auto-Logger**:
  - Whenever you submit and your solution is **Accepted** or **Correct**, CodeTrack automatically detects the verdict in real time and logs the problem in the background.
  - Injects a sleek in-page floating toast notification with direct link to your Dashboard!
  - Can be toggled ON / OFF anytime inside the extension popup.
- **Zero-Friction Authentication**:
  - **1-Click Connect**: If you have `https://codetrack-henna.vercel.app` (or local client) open in any tab, click **"1-Click Connect from CodeTrack Tab"** to sync your login session instantly.
  - Or log in manually using your CodeTrack email & password.
- **Adaptive Spaced Repetition (SM-2)**: Choose your next revision interval (3, 7, 14, 30 days) before logging.
- **Direct Cloud Sync**: Problems are submitted directly to `POST https://codetrack-server.onrender.com/api/problems` and instantly appear in your CodeTrack Dashboard and master problem list.
- **Environment Toggle**: Click the **Cloud / Local** badge in the header anytime to toggle between live Render server and `http://localhost:5000`.
