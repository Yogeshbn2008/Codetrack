# ⚡ CodeTrack Companion — Manifest V3 Chrome Extension

1-Click auto-logger for LeetCode & DSA problems directly into your CodeTrack account.

---

## 🚀 How to Install in Google Chrome

1. Open Google Chrome and go to:
   ```
   chrome://extensions
   ```
2. In the top right corner, toggle on **"Developer mode"**.
3. Click the **"Load unpacked"** button in the top left.
4. Select the directory:
   ```
   C:\Users\bnyog\OneDrive\Desktop\codetrack-extension
   ```
5. Pin **CodeTrack Companion** to your Chrome toolbar for instant access!

---

## ⚡ Features & Workflow

- **Auto-Extraction from LeetCode**: When you are on any LeetCode problem page (`leetcode.com/problems/<problem-name>`), clicking the extension automatically extracts:
  - Problem Title (e.g., "Two Sum")
  - Difficulty level (`Easy`, `Medium`, `Hard`)
  - Topic Tags (e.g., `Array`, `Dynamic Programming`)
  - Problem Link & Platform (`LeetCode`)
  - Acceptance status (`Solved` vs `Attempted`)
- **Zero-Friction Authentication**:
  - **1-Click Connect**: If you have `https://codetrack-henna.vercel.app` (or local client) open in any tab, click **"1-Click Connect from CodeTrack Tab"** to sync your login session instantly.
  - Or log in manually using your CodeTrack email & password.
- **Adaptive Spaced Repetition (SM-2)**: Choose your next revision interval (3, 7, 14, 30 days) before logging.
- **Direct Cloud Sync**: Problems are submitted directly to `POST https://codetrack-server.onrender.com/api/problems` and instantly appear in your CodeTrack Dashboard and master problem list.
- **Environment Toggle**: Click the **Cloud / Local** badge in the header anytime to toggle between live Render server and `http://localhost:5000`.
